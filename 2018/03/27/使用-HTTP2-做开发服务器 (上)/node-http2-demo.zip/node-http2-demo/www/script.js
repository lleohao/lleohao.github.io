const content = document.querySelector("#content");

content.innerHTML = `<h1>Hello HTTP/2</h1>`;
